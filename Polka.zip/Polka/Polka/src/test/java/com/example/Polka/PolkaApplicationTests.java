package com.example.Polka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
